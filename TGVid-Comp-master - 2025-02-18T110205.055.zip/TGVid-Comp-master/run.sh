python3 bot.py
